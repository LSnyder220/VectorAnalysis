# -*- coding: utf-8 -*-
"""
Created on Wed Apr 12 15:40:08 2023

@author: tug03166
"""

import arcpy
import os



# set arcgis workspace
arcpy.env.workspace = os.getcwd()

# identify inclusion zone
Empower_Zone = 'PhiladelphiaEmpowermentZones201201.shp'
    
# within 2000ft of High Speed Stations
High_Speed = arcpy.analysis.Buffer('SEPTAGISHighspeedStations_201207.shp', 'HighSpeedBuffer.shp', 2000, dissolve_option = "ALL")
    
# reproject Regional Rail Stations
# 'NAD_1983_StatePlane_Pennsylvania_South_FIPS_3702_Feet'
RRreproject = arcpy.management.Project('SEPTAGISRegionalRailStations_2016.shp','RRreproject.shp', arcpy.SpatialReference(102729))
    
# within 2000ft of Regional Rail Stations
Regional_Rail = arcpy.analysis.Buffer('RRreproject.shp', 'Regional_Rail.shp', 2000, dissolve_option = "ALL")

# either public transport buffers
Septa = arcpy.management.Merge([High_Speed, Regional_Rail], 'Septa.shp')

# inclusion_layer = intersection of layers' areas to include
inclusion_layer = arcpy.analysis.Intersect([Empower_Zone, Septa], 'inclusion_layer.shp')




# identify exclusion zone
# (not) within 1200ft of Farmers Markets
Farm_Markets = arcpy.analysis.Buffer('PhillyHealth_Farmers_Markets.shp', 'FarmersBuffer.shp', 1200, dissolve_option = "ALL")

# (not) within 1200ft of Healthy Corner Stores
Health_Corners = arcpy.analysis.Buffer('PhillyHealth_Healthy_corner_stores.shp', 'HealthCornersBuffer.shp', 1200, dissolve_option = "ALL")

# exclusion_layer = calculated area of layers' areas to exclude
exclusion_layer = arcpy.management.Merge([Farm_Markets, Health_Corners], 'exclusion_layer.shp')





# erase exclusion_dis from inclusion_dis
suitable_layer = arcpy.Erase_analysis(inclusion_layer, exclusion_layer, 'suitable_layer.shp')

# make one polygon
suitable_layer_onepoly = arcpy.MultipartToSinglepart_management(suitable_layer, 'suitable_layer_onepoly.shp')

# arcpy.AddGeometryAttributes_management to calculate area
arcpy.AddGeometryAttributes_management(suitable_layer_onepoly, 'AREA')

print('Process done.')
# LARGEST AREA OF SINGLE ELIGABLE POLYGON = 4049487.50644
